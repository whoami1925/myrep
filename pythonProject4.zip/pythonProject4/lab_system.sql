-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 26 2025 г., 20:26
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lab_system`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accountants`
--

CREATE TABLE `accountants` (
  `accountant_id` int NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `services_invoiced` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `accountants`
--

INSERT INTO `accountants` (`accountant_id`, `login`, `password`, `full_name`, `last_login`, `services_invoiced`) VALUES
(1, '2', '2', '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `administrators`
--

CREATE TABLE `administrators` (
  `admin_id` int NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `administrators`
--

INSERT INTO `administrators` (`admin_id`, `login`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Структура таблицы `analyzers`
--

CREATE TABLE `analyzers` (
  `analyzer_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `last_maintenance_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `archived_orders`
--

CREATE TABLE `archived_orders` (
  `archive_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `archive_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `blocked_users`
--

CREATE TABLE `blocked_users` (
  `login` varchar(50) NOT NULL,
  `block_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `blocked_users`
--

INSERT INTO `blocked_users` (`login`, `block_until`) VALUES
('admin', '2025-02-26 15:55:06');

-- --------------------------------------------------------

--
-- Структура таблицы `insurance_companies`
--

CREATE TABLE `insurance_companies` (
  `company_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `inn` varchar(20) DEFAULT NULL,
  `bank_account` varchar(50) DEFAULT NULL,
  `bic` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `lab_technicians`
--

CREATE TABLE `lab_technicians` (
  `technician_id` int NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `services_available` varchar(255) DEFAULT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'lab_technician'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `lab_technicians`
--

INSERT INTO `lab_technicians` (`technician_id`, `login`, `password`, `full_name`, `last_login`, `services_available`, `role`) VALUES
(5, 'lt', 'lt', 'lt', NULL, NULL, 'lab_technician');

-- --------------------------------------------------------

--
-- Структура таблицы `login_history`
--

CREATE TABLE `login_history` (
  `history_id` int NOT NULL,
  `user_login` varchar(50) NOT NULL,
  `login_time` datetime NOT NULL,
  `successful` tinyint(1) NOT NULL,
  `user_type` enum('lab_technician','accountant','administrator') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `login_history`
--

INSERT INTO `login_history` (`history_id`, `user_login`, `login_time`, `successful`, `user_type`) VALUES
(14, 'admin', '2025-02-26 15:54:48', 0, 'lab_technician'),
(15, 'admin', '2025-02-26 15:54:54', 0, 'lab_technician'),
(16, 'admin', '2025-02-26 15:55:29', 0, 'lab_technician'),
(17, 'admin', '2025-02-26 15:56:13', 0, 'lab_technician'),
(18, 'admin', '2025-02-26 16:08:59', 1, 'administrator'),
(19, 'admin', '2025-02-26 16:18:46', 1, 'administrator'),
(20, '2', '2025-02-26 16:19:28', 1, 'accountant'),
(21, 'lt', '2025-02-26 16:36:01', 1, 'lab_technician'),
(22, 'admin', '2025-02-26 16:54:19', 1, 'administrator'),
(23, 'lt', '2025-02-26 16:58:34', 1, 'lab_technician'),
(24, 'lt', '2025-02-26 16:59:33', 1, 'lab_technician'),
(25, '2', '2025-02-26 16:59:40', 1, 'accountant'),
(26, 'admin', '2025-02-26 17:00:21', 1, 'administrator'),
(27, 'lt', '2025-02-26 17:14:30', 1, 'lab_technician'),
(28, 'lt', '2025-02-26 17:19:03', 1, 'lab_technician'),
(29, '2', '2025-02-26 17:19:27', 1, 'accountant'),
(30, 'admin', '2025-02-26 17:19:53', 1, 'administrator'),
(31, 'lt', '2025-02-26 17:23:31', 1, 'lab_technician'),
(32, 'lt', '2025-02-26 17:26:45', 1, 'lab_technician'),
(33, '2', '2025-02-26 17:26:57', 1, 'accountant'),
(34, 'admin', '2025-02-26 17:27:16', 1, 'administrator'),
(35, 'lt', '2025-02-26 17:28:32', 1, 'lab_technician'),
(36, 'lt', '2025-02-26 17:38:05', 1, 'lab_technician'),
(37, '2', '2025-02-26 17:38:48', 1, 'accountant'),
(38, '2', '2025-02-26 17:39:23', 1, 'accountant'),
(39, '2', '2025-02-26 17:39:44', 1, 'accountant'),
(40, '2', '2025-02-26 17:40:02', 1, 'accountant'),
(41, 'lt', '2025-02-26 17:41:28', 1, 'lab_technician'),
(42, '2', '2025-02-26 17:41:50', 1, 'accountant'),
(43, 'lt', '2025-02-26 17:42:01', 1, 'lab_technician'),
(44, '2', '2025-02-26 18:38:06', 1, 'accountant'),
(45, 'lt', '2025-02-26 18:38:16', 1, 'lab_technician'),
(46, 'admin', '2025-02-26 18:38:31', 1, 'administrator'),
(47, 'lt', '2025-02-26 18:41:25', 1, 'lab_technician'),
(48, 'lt', '2025-02-26 18:42:15', 1, 'lab_technician'),
(49, 'lt', '2025-02-26 18:53:05', 1, 'lab_technician'),
(50, 'lt', '2025-02-26 19:14:03', 1, 'lab_technician'),
(51, 'lt', '2025-02-26 19:17:00', 1, 'lab_technician'),
(52, 'lt', '2025-02-26 19:19:24', 1, 'lab_technician'),
(53, 'lt', '2025-02-26 19:21:13', 1, 'lab_technician'),
(54, 'lt', '2025-02-26 19:22:12', 1, 'lab_technician'),
(55, 'lt', '2025-02-26 19:27:08', 1, 'lab_technician'),
(56, 'lt', '2025-02-26 19:30:12', 1, 'lab_technician'),
(57, '2', '2025-02-26 19:30:23', 1, 'accountant'),
(58, 'admin', '2025-02-26 19:30:46', 1, 'administrator'),
(59, 'lt', '2025-02-26 19:36:33', 1, 'lab_technician'),
(60, 'lt', '2025-02-26 19:39:23', 1, 'lab_technician'),
(61, 'lt', '2025-02-26 19:40:04', 1, 'lab_technician'),
(62, 'lt', '2025-02-26 19:44:47', 1, 'lab_technician'),
(63, 'lt', '2025-02-26 19:50:05', 1, 'lab_technician'),
(64, 'lt', '2025-02-26 19:52:08', 1, 'lab_technician'),
(65, 'lt', '2025-02-26 20:08:17', 1, 'lab_technician');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `patient_id` int DEFAULT NULL,
  `order_date` date NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`order_id`, `patient_id`, `order_date`, `status`) VALUES
(1, 1, '2025-02-26', 'Новый');

-- --------------------------------------------------------

--
-- Структура таблицы `order_services`
--

CREATE TABLE `order_services` (
  `order_id` int NOT NULL,
  `service_id` int NOT NULL,
  `status` varchar(50) NOT NULL,
  `execution_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_services`
--

INSERT INTO `order_services` (`order_id`, `service_id`, `status`, `execution_time`) VALUES
(1, 1, 'Новый', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `patients`
--

CREATE TABLE `patients` (
  `patient_id` int NOT NULL,
  `login` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `birth_date` date NOT NULL,
  `passport_series` varchar(10) DEFAULT NULL,
  `passport_number` varchar(10) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `insurance_number` varchar(50) DEFAULT NULL,
  `insurance_type` varchar(50) DEFAULT NULL,
  `insurance_company` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `patients`
--

INSERT INTO `patients` (`patient_id`, `login`, `password`, `full_name`, `birth_date`, `passport_series`, `passport_number`, `phone`, `email`, `insurance_number`, `insurance_type`, `insurance_company`) VALUES
(1, 't@gmail.com', NULL, 't', '2000-11-11', '2222', ' 222222', '2323123213', 't@gmail.com', '21321', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `provided_services`
--

CREATE TABLE `provided_services` (
  `provided_service_id` int NOT NULL,
  `service_id` int DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `analyzer_id` int DEFAULT NULL,
  `executed_by` int DEFAULT NULL,
  `execution_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reports`
--

CREATE TABLE `reports` (
  `id` int NOT NULL,
  `technician_login` varchar(255) DEFAULT NULL,
  `report_data` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `reports`
--

INSERT INTO `reports` (`id`, `technician_login`, `report_data`, `created_at`) VALUES
(1, 'lt', '1', '2025-02-26 14:19:17'),
(2, 'lt', 'test', '2025-02-26 14:42:16'),
(3, '1', 'test2', '2025-02-26 16:14:16');

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE `services` (
  `service_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `code` varchar(50) NOT NULL,
  `execution_time` int NOT NULL,
  `average_deviation` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`service_id`, `name`, `price`, `code`, `execution_time`, `average_deviation`) VALUES
(1, 'Анализ крови', '1000.00', 'BLOOD', 24, '2.00'),
(2, 'Биохимический анализ', '1500.00', 'BIO', 48, '3.00'),
(3, 'Генетический тест', '5000.00', 'GEN', 72, '5.00'),
(4, 'Иммунологический анализ', '2000.00', 'IMM', 36, '2.00');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `accountants`
--
ALTER TABLE `accountants`
  ADD PRIMARY KEY (`accountant_id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `administrators`
--
ALTER TABLE `administrators`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `analyzers`
--
ALTER TABLE `analyzers`
  ADD PRIMARY KEY (`analyzer_id`);

--
-- Индексы таблицы `archived_orders`
--
ALTER TABLE `archived_orders`
  ADD PRIMARY KEY (`archive_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `blocked_users`
--
ALTER TABLE `blocked_users`
  ADD PRIMARY KEY (`login`);

--
-- Индексы таблицы `insurance_companies`
--
ALTER TABLE `insurance_companies`
  ADD PRIMARY KEY (`company_id`);

--
-- Индексы таблицы `lab_technicians`
--
ALTER TABLE `lab_technicians`
  ADD PRIMARY KEY (`technician_id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `user_login` (`user_login`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Индексы таблицы `order_services`
--
ALTER TABLE `order_services`
  ADD PRIMARY KEY (`order_id`,`service_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Индексы таблицы `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `provided_services`
--
ALTER TABLE `provided_services`
  ADD PRIMARY KEY (`provided_service_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `accountants`
--
ALTER TABLE `accountants`
  MODIFY `accountant_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `administrators`
--
ALTER TABLE `administrators`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `analyzers`
--
ALTER TABLE `analyzers`
  MODIFY `analyzer_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `archived_orders`
--
ALTER TABLE `archived_orders`
  MODIFY `archive_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `insurance_companies`
--
ALTER TABLE `insurance_companies`
  MODIFY `company_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `lab_technicians`
--
ALTER TABLE `lab_technicians`
  MODIFY `technician_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `login_history`
--
ALTER TABLE `login_history`
  MODIFY `history_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `provided_services`
--
ALTER TABLE `provided_services`
  MODIFY `provided_service_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `archived_orders`
--
ALTER TABLE `archived_orders`
  ADD CONSTRAINT `archived_orders_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);

--
-- Ограничения внешнего ключа таблицы `order_services`
--
ALTER TABLE `order_services`
  ADD CONSTRAINT `order_services_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`);

--
-- Ограничения внешнего ключа таблицы `provided_services`
--
ALTER TABLE `provided_services`
  ADD CONSTRAINT `provided_services_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`),
  ADD CONSTRAINT `provided_services_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
