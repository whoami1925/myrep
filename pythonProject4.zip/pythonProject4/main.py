from user_interface import open_login_window

if __name__ == "__main__":
    open_login_window()
