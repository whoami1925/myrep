from db import connect_db
import random
import string
from datetime import datetime, timedelta
import bcrypt

# Генерация CAPTCHA
def generate_captcha():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choices(characters, k=4))


# Проверка блокировки пользователя
def check_user_blocked(login):
    conn = connect_db()
    cursor = conn.cursor()
    query = "SELECT block_until FROM blocked_users WHERE login = %s"
    cursor.execute(query, (login,))
    result = cursor.fetchone()
    return result and result[0] > datetime.now()


# Блокировка пользователя
def block_user(login, seconds=30):
    conn = connect_db()
    cursor = conn.cursor()
    block_until = datetime.now() + timedelta(seconds=seconds)
    query = """INSERT INTO blocked_users (login, block_until)
               VALUES (%s, %s) ON DUPLICATE KEY UPDATE block_until = %s"""
    cursor.execute(query, (login, block_until, block_until))
    conn.commit()




def authenticate_user(login, password):
    conn = connect_db()
    cursor = conn.cursor()

    # Проверяем в таблице lab_technicians
    query = "SELECT password FROM lab_technicians WHERE login = %s"
    cursor.execute(query, (login,))
    result = cursor.fetchone()

    if result:
        stored_password = result[0]
        if stored_password == password:
            return True, 'lab_technician'

    # Проверяем в таблице accountants
    query = "SELECT password FROM accountants WHERE login = %s"
    cursor.execute(query, (login,))
    result = cursor.fetchone()

    if result:
        stored_password = result[0]
        if stored_password == password:
            return True, 'accountant'

    # Проверяем в таблице administrators
    query = "SELECT password FROM administrators WHERE login = %s"
    cursor.execute(query, (login,))
    result = cursor.fetchone()

    if result:
        stored_password = result[0]
        if stored_password == password:
            return True, 'administrator'

    return False, None


def register_user(login, password, full_name, role):
    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Удаляем лишние пробелы и приводим к нижнему регистру
        login = login.strip().lower()
        print(f"Регистрируем пользователя: Логин='{login}', Полное имя='{full_name}', Роль='{role}'")

        # Проверяем, есть ли уже такой пользователь в соответствующей таблице
        if role == 'lab_technician':
            check_query = "SELECT login FROM lab_technicians WHERE LOWER(login) = %s"
            insert_query = """INSERT INTO lab_technicians (login, password, full_name)
                              VALUES (%s, %s, %s)"""
        elif role == 'accountant':
            check_query = "SELECT login FROM accountants WHERE LOWER(login) = %s"
            insert_query = """INSERT INTO accountants (login, password, full_name)
                              VALUES (%s, %s, %s)"""
        elif role == 'administrator':
            check_query = "SELECT login FROM administrators WHERE LOWER(login) = %s"
            insert_query = """INSERT INTO administrators (login, password)
                              VALUES (%s, %s)"""
        else:
            print("Ошибка: Неверная роль пользователя.")
            return False

        # Проверяем, есть ли уже такой пользователь
        cursor.execute(check_query, (login,))
        if cursor.fetchone():
            print("Ошибка: Логин уже занят.")
            return False

        # Добавляем нового пользователя в соответствующую таблицу
        if role == 'administrator':
            cursor.execute(insert_query, (login, password))
        else:
            cursor.execute(insert_query, (login, password, full_name))

        conn.commit()
        print("Пользователь успешно зарегистрирован.")
        return True

    except Exception as e:
        print(f"Ошибка при регистрации: {e}")
        conn.rollback()
        return False

    finally:
        cursor.close()
        conn.close()

def log_login_attempt(login, successful, role):
    conn = connect_db()
    cursor = conn.cursor()

    try:
        query = """INSERT INTO login_history (user_login, login_time, successful, user_type)
                   VALUES (%s, %s, %s, %s)"""
        cursor.execute(query, (login, datetime.now(), successful, role))
        conn.commit()

    except Exception as e:
        print(f"Ошибка при записи истории входа: {e}")
        conn.rollback()

    finally:
        cursor.close()
        conn.close()
