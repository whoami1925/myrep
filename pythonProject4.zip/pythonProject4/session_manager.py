import tkinter as tk
from tkinter import messagebox
import threading
import time

SESSION_TIME = 600  # 10 минут (для тестов)
WARNING_TIME = 300  # 5 минут
BLOCK_TIME = 60  # 1 минута


def show_warning():
    messagebox.showwarning("Предупреждение", "Сеанс истекает через 5 минут!")


def end_session(root):
    messagebox.showinfo("Сеанс завершен", "Сеанс завершен, вход заблокирован на 1 минуту.")
    root.quit()


def start_session_timer(root):
    def timer_thread():
        time.sleep(WARNING_TIME)
        show_warning()
        time.sleep(SESSION_TIME - WARNING_TIME)
        end_session(root)

    threading.Thread(target=timer_thread, daemon=True).start()
