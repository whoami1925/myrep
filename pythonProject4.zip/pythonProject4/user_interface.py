import tkinter as tk
from barcode import Code128
from barcode.writer import ImageWriter
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from tkinter import messagebox
from session_manager import start_session_timer
from auth import authenticate_user, generate_captcha, check_user_blocked, block_user, log_login_attempt, register_user
from db import connect_db
from tkinter import simpledialog

import os
from datetime import datetime

def generate_barcode(order_id):
    # Генерация штрих-кода
    barcode = Code128(str(order_id), writer=ImageWriter())
    barcode_filename = f"barcode_{order_id}"
    barcode.save(barcode_filename)
    return barcode_filename + ".png"

def generate_pdf(order_id, patient_name, services, total_cost):
    # Генерация PDF
    pdf_filename = f"order_{order_id}.pdf"
    c = canvas.Canvas(pdf_filename, pagesize=A4)
    c.drawString(100, 750, f"Заказ №: {order_id}")
    c.drawString(100, 730, f"Пациент: {patient_name}")
    c.drawString(100, 710, "Услуги:")
    y = 690
    for service in services:
        c.drawString(120, y, f"- {service}")
        y -= 20
    c.drawString(100, y - 20, f"Общая стоимость: {total_cost} руб.")
    c.save()
    return pdf_filename

def attempt_login(login_entry, password_entry, captcha_entry, login_window, captcha_label, show_captcha):
    login = login_entry.get()
    password = password_entry.get()

    if check_user_blocked(login):
        messagebox.showerror("Ошибка", "Вы заблокированы. Попробуйте позже.")
        return

    # Проверяем авторизацию
    success, role = authenticate_user(login, password)

    if success:
        log_login_attempt(login, True, role)  # Передаем роль пользователя
        login_window.destroy()
        open_user_window(role)
    else:
        log_login_attempt(login, False, role)  # Передаем роль пользователя
        messagebox.showerror("Ошибка", "Неверный логин или пароль.")

        # После первой ошибки отображаем CAPTCHA
        if not show_captcha.get():
            show_captcha.set(True)
            captcha_label.config(text=generate_captcha())

        # Если уже была CAPTCHA и снова ошибка, блокируем
        elif captcha_entry.get() != captcha_label.cget("text"):
            messagebox.showerror("Ошибка", "Неверная CAPTCHA.")
            block_user(login, 10)  # Блокируем на 10 секунд


def open_login_window():
    login_window = tk.Tk()
    login_window.title("Окно входа")
    login_window.geometry("400x300")  # Увеличено

    show_captcha = tk.BooleanVar(value=False)

    login_label = tk.Label(login_window, text="Логин:")
    login_label.pack()
    login_entry = tk.Entry(login_window)
    login_entry.pack()

    password_label = tk.Label(login_window, text="Пароль:")
    password_label.pack()
    password_entry = tk.Entry(login_window, show="*")
    password_entry.pack()

    # CAPTCHA (по умолчанию скрыта)
    captcha_label = tk.Label(login_window, text="")
    captcha_label.pack_forget()
    captcha_entry = tk.Entry(login_window)
    captcha_entry.pack_forget()

    def update_captcha_display(*args):
        if show_captcha.get():
            captcha_label.pack()
            captcha_entry.pack()
        else:
            captcha_label.pack_forget()
            captcha_entry.pack_forget()

    show_captcha.trace("w", update_captcha_display)

    login_button = tk.Button(
        login_window, text="Войти",
        command=lambda: attempt_login(login_entry, password_entry, captcha_entry, login_window, captcha_label,
                                      show_captcha)
    )
    login_button.pack()

    register_button = tk.Button(
        login_window, text="Регистрация", command=open_register_window
    )
    register_button.pack()

    login_window.mainloop()


def open_register_window():
    register_window = tk.Tk()
    register_window.title("Регистрация")
    register_window.geometry("400x350")

    login_label = tk.Label(register_window, text="Логин:")
    login_label.pack()
    login_entry = tk.Entry(register_window)
    login_entry.pack()

    password_label = tk.Label(register_window, text="Пароль:")
    password_label.pack()
    password_entry = tk.Entry(register_window, show="*")
    password_entry.pack()

    full_name_label = tk.Label(register_window, text="ФИО:")
    full_name_label.pack()
    full_name_entry = tk.Entry(register_window)
    full_name_entry.pack()

    role_label = tk.Label(register_window, text="Роль (lab_technician/accountant/administrator):")
    role_label.pack()
    role_entry = tk.Entry(register_window)
    role_entry.pack()

    def register():
        login = login_entry.get()
        password = password_entry.get()
        full_name = full_name_entry.get()
        role = role_entry.get()

        success, message = register_user(login, password, full_name, role)

        if success:
            messagebox.showinfo("Успех", message)
            register_window.destroy()
        else:
            messagebox.showerror("Ошибка", message)

    # Добавляем кнопку "Зарегистрироваться"
    register_button = tk.Button(register_window, text="Зарегистрироваться", command=register)
    register_button.pack(pady=10)

    register_window.mainloop()

def accept_biomaterial():
    def save_order():
        tube_code = tube_code_entry.get()
        patient_name = patient_name_entry.get()
        selected_services = services_listbox.curselection()

        if not tube_code or not patient_name or not selected_services:
            messagebox.showerror("Ошибка", "Заполните все поля и выберите услуги.")
            return

        conn = connect_db()
        cursor = conn.cursor()

        try:
            # Проверяем, есть ли пациент в базе данных
            cursor.execute("SELECT patient_id FROM patients WHERE full_name = %s", (patient_name,))
            patient = cursor.fetchone()

            if not patient:
                # Если пациента нет, открываем окно для добавления
                add_patient_window = tk.Toplevel()
                add_patient_window.title("Добавить пациента")

                # Поля для ввода данных пациента
                tk.Label(add_patient_window, text="ФИО:").pack()
                full_name_entry = tk.Entry(add_patient_window)
                full_name_entry.pack()

                tk.Label(add_patient_window, text="Дата рождения (ГГГГ-ММ-ДД):").pack()
                birth_date_entry = tk.Entry(add_patient_window)
                birth_date_entry.pack()

                tk.Label(add_patient_window, text="Паспорт (серия и номер):").pack()
                passport_entry = tk.Entry(add_patient_window)
                passport_entry.pack()

                tk.Label(add_patient_window, text="Телефон:").pack()
                phone_entry = tk.Entry(add_patient_window)
                phone_entry.pack()

                tk.Label(add_patient_window, text="Email:").pack()
                email_entry = tk.Entry(add_patient_window)
                email_entry.pack()

                tk.Label(add_patient_window, text="Страховой полис:").pack()
                insurance_entry = tk.Entry(add_patient_window)
                insurance_entry.pack()

                def save_patient():
                    """Сохранение нового пациента в базу данных."""
                    full_name = full_name_entry.get()
                    birth_date = birth_date_entry.get()
                    passport = passport_entry.get()
                    phone = phone_entry.get()
                    email = email_entry.get()
                    insurance = insurance_entry.get()

                    # Используем email в качестве логина (или phone, если email отсутствует)
                    login = email if email else phone

                    cursor.execute(
                        "INSERT INTO patients (full_name, birth_date, passport_series, passport_number, phone, email, insurance_number, login) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                        (full_name, birth_date, passport[:4], passport[4:], phone, email, insurance, login)
                    )
                    conn.commit()
                    add_patient_window.destroy()
                    messagebox.showinfo("Успех", "Пациент добавлен.")

                tk.Button(add_patient_window, text="Сохранить", command=save_patient).pack()
                add_patient_window.grab_set()  # Делаем окно модальным
                add_patient_window.wait_window()

                # Повторно проверяем наличие пациента
                cursor.execute("SELECT patient_id FROM patients WHERE full_name = %s", (patient_name,))
                patient = cursor.fetchone()

            patient_id = patient[0]

            # Создаем заказ
            order_date = datetime.now().strftime("%Y-%m-%d")
            cursor.execute("INSERT INTO orders (patient_id, order_date, status) VALUES (%s, %s, 'Новый')",
                           (patient_id, order_date))
            order_id = cursor.lastrowid

            # Добавляем услуги к заказу
            services = []
            total_cost = 0
            for service_index in selected_services:
                service_name = services_listbox.get(service_index)
                cursor.execute("SELECT service_id, price FROM services WHERE name = %s", (service_name,))
                service = cursor.fetchone()
                services.append(service_name)
                total_cost += service[1]
                cursor.execute("INSERT INTO order_services (order_id, service_id, status) VALUES (%s, %s, 'Новый')",
                               (order_id, service[0]))

            conn.commit()

            # Генерация штрих-кода и PDF
            barcode_filename = generate_barcode(order_id)
            pdf_filename = generate_pdf(order_id, patient_name, services, total_cost)

            messagebox.showinfo("Успех", f"Заказ №{order_id} создан. Штрих-код и PDF сохранены.")

            # Очистка полей
            tube_code_entry.delete(0, tk.END)
            patient_name_entry.delete(0, tk.END)
            services_listbox.selection_clear(0, tk.END)

        except Exception as e:
            conn.rollback()
            messagebox.showerror("Ошибка", f"Ошибка при сохранении заказа: {e}")
        finally:
            cursor.close()
            conn.close()

    # Окно для приема биоматериала
    biomaterial_window = tk.Toplevel()
    biomaterial_window.title("Прием биоматериала")

    # Поле для ввода кода пробирки
    tk.Label(biomaterial_window, text="Код пробирки:").pack()
    tube_code_entry = tk.Entry(biomaterial_window)
    tube_code_entry.pack()

    # Поле для ввода ФИО пациента
    tk.Label(biomaterial_window, text="ФИО пациента:").pack()
    patient_name_entry = tk.Entry(biomaterial_window)
    patient_name_entry.pack()

    # Список услуг
    tk.Label(biomaterial_window, text="Выберите услуги:").pack()
    services_listbox = tk.Listbox(biomaterial_window, selectmode=tk.MULTIPLE)
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM services")
    for service in cursor.fetchall():
        services_listbox.insert(tk.END, service[0])
    services_listbox.pack()

    # Кнопка для сохранения заказа
    tk.Button(biomaterial_window, text="Сохранить заказ", command=save_order).pack()


def generate_report():
    conn = connect_db()
    cursor = conn.cursor()

    technician_login = simpledialog.askstring("Сформировать отчёт", "Введите ваш логин:")
    if not technician_login:
        return

    report_data = simpledialog.askstring("Сформировать отчёт", "Введите данные отчёта:")
    if not report_data:
        return

    try:
        cursor.execute("INSERT INTO reports (technician_login, report_data, created_at) VALUES (%s, %s, NOW())",
                       (technician_login, report_data))
        conn.commit()
        messagebox.showinfo("Успех", "Отчёт успешно сохранён!")

    except Exception as e:
        conn.rollback()
        messagebox.showerror("Ошибка", f"Ошибка при сохранении отчёта: {e}")

    finally:
        cursor.close()
        conn.close()

def issue_invoice():
    conn = connect_db()
    cursor = conn.cursor()

    order_id = simpledialog.askinteger("Выставить счёт", "Введите ID заказа:")
    if not order_id:
        return

    amount = simpledialog.askfloat("Выставить счёт", "Введите сумму счёта:")
    if not amount:
        return

    try:
        cursor.execute("INSERT INTO provided_services (order_id, execution_date) VALUES (%s, NOW())", (order_id,))
        conn.commit()
        messagebox.showinfo("Успех", f"Счёт на {amount} руб. выставлен для заказа #{order_id}")

    except Exception as e:
        conn.rollback()
        messagebox.showerror("Ошибка", f"Ошибка при выставлении счёта: {e}")

    finally:
        cursor.close()
        conn.close()

def view_reports():
    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT id, technician_login, report_data, created_at FROM reports")
        reports = cursor.fetchall()

        if not reports:
            messagebox.showinfo("Просмотр отчётов", "Отчёты отсутствуют.")
            return

        report_text = "\n".join([f"#{r[0]} | {r[1]} | {r[3]}: {r[2]}" for r in reports])
        messagebox.showinfo("Отчёты", report_text)

    except Exception as e:
        messagebox.showerror("Ошибка", f"Ошибка при загрузке отчётов: {e}")

    finally:
        cursor.close()
        conn.close()

def control_users():
    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT login, full_name, 'Лаборант' FROM lab_technicians "
                       "UNION ALL SELECT login, full_name, 'Бухгалтер' FROM accountants "
                       "UNION ALL SELECT login, 'Администратор', 'Администратор' FROM administrators")
        users = cursor.fetchall()

        if not users:
            messagebox.showinfo("Контроль пользователей", "Нет зарегистрированных пользователей.")
            return

        user_text = "\n".join([f"{u[0]} ({u[2]}): {u[1]}" for u in users])
        messagebox.showinfo("Пользователи", user_text)

    except Exception as e:
        messagebox.showerror("Ошибка", f"Ошибка при загрузке пользователей: {e}")

    finally:
        cursor.close()
        conn.close()

def view_login_history():
    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT user_login, login_time, successful FROM login_history ORDER BY login_time DESC")
        history = cursor.fetchall()

        if not history:
            messagebox.showinfo("История входов", "История входов отсутствует.")
            return

        history_text = "\n".join([f"{h[1]} | {h[0]} | {'Успешно' if h[2] else 'Ошибка'}" for h in history])
        messagebox.showinfo("История входов", history_text)

    except Exception as e:
        messagebox.showerror("Ошибка", f"Ошибка при загрузке истории входов: {e}")

    finally:
        cursor.close()
        conn.close()

def manage_consumables():
    conn = connect_db()
    cursor = conn.cursor()

    material_name = simpledialog.askstring("Расходные материалы", "Введите название расходника:")
    if not material_name:
        return

    quantity = simpledialog.askinteger("Расходные материалы", "Введите количество:")
    if not quantity:
        return

    try:
        cursor.execute("INSERT INTO materials (name, quantity) VALUES (%s, %s) ON DUPLICATE KEY UPDATE quantity = quantity + %s",
                       (material_name, quantity, quantity))
        conn.commit()
        messagebox.showinfo("Успех", f"Добавлено {quantity} единиц {material_name}")

    except Exception as e:
        conn.rollback()
        messagebox.showerror("Ошибка", f"Ошибка при обновлении расходников: {e}")

    finally:
        cursor.close()
        conn.close()


def open_user_window(role):
    user_window = tk.Tk()
    user_window.title(f"Добро пожаловать, {role}")
    user_window.geometry("500x400")

    label = tk.Label(user_window, text=f"Вы вошли как {role}", font=("Arial", 14))
    label.pack(pady=10)

    if role == 'lab_technician':
        tk.Button(user_window, text="Принять биоматериал", command=accept_biomaterial).pack(pady=5)
        tk.Button(user_window, text="Сформировать отчёт", command=generate_report).pack(pady=5)

    elif role == 'accountant':
        tk.Button(user_window, text="Просмотр отчётов", command=view_reports).pack(pady=5)
        tk.Button(user_window, text="Выставить счёт", command=issue_invoice).pack(pady=5)

    elif role == 'administrator':
        tk.Button(user_window, text="Контроль пользователей", command=control_users).pack(pady=5)
        tk.Button(user_window, text="Просмотр истории входов", command=view_login_history).pack(pady=5)
        tk.Button(user_window, text="Работа с расходными материалами", command=manage_consumables).pack(pady=5)

    tk.Button(user_window, text="Выход", command=user_window.destroy).pack(pady=10)

    # Таймер сеанса
    start_session_timer(user_window)

    user_window.mainloop()




